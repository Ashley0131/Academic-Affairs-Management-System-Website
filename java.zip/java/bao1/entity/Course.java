package bao1.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="COURSE")
public class Course {
	@Id
	private String sn;
	@Column(name="caption")
	private String caption;
	@Column(name="path")
	private String path;
	@Column(name="teacherAccount")
	private String teacherAccount;
	/*@Transient
	private List<CourseResource> resources=new ArrayList<CourseResource>();
	
	//@XmlAttribute
	public List<CourseResource> getResources() {
		return resources;
	}
	public void setResources(List<CourseResource> resources) {
		this.resources = resources;
	}*/
	public String getSn() {
		return sn;
	}
	public void setSn(String sn) {
		this.sn = sn;
	}
	public String getCaption() {
		return caption;
	}
	public void setCaption(String caption) {
		this.caption = caption;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public String getTeacherAccount() {
		return teacherAccount;
	}
	public void setTeacherAccount(String teacherAccount) {
		this.teacherAccount = teacherAccount;
	}
}
