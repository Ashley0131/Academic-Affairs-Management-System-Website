package bao1.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 用户信息
 * @author 27205
 *
 */
@Entity
@Table(name="USER")
public class User {
	
	/**
	 * 用户id,id表示该变量对应数据库表中的主键，column表示变量对应数据表中的列名
	 */
	@Id
	@Column(name="ID")
	private int id;
	/**
	 * 用户账号
	 */
	@Column(name="ACCOUNT")
	private String account;
	/**
	 * 用户密码
	 */
	@Column(name="PASSWORD")
	private String password;
	/**
	 * 用户昵称
	 */
	@Column(name="nickname")
	private String nickname;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
}
