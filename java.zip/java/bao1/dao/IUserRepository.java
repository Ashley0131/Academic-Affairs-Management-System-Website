/**
 * 
 */
package bao1.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import bao1.entity.User;

/**
 * @author 27205
 *自定义JPA库类必须是接口且继承JpaRepository，第一个是某实体类，第二个是该实体类的主键的类型
 */
@Repository
public interface IUserRepository extends JpaRepository<User,Integer>{
	/**
	 * 按名字查找，多个则返回List<User>
	 * 方法通过Query注解说明且执行内容
	 * Query注解中的字符串类是SQL的查询语句，其中把表名换成了类名，表字段名换成了成员变量名
	 * 若用到函数参数，用?1,?2来指定
	 * @param name
	 * @return
	 */
	//查找指定用户
	@Query("select ur from User ur where ur.account=?1")
	public User findByAccount(String account);
	@Query("select ur from User ur where ur.account=?1 and ur.password=?2")
	public User findByAccountAndPassword(String account,String password);
	@Query("select id,account,password from User u where u.account=?1")
	public List<User> getUserByname(String name);
}
