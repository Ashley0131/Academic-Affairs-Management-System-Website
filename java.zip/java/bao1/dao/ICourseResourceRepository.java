package bao1.dao;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import bao1.entity.CourseResource;
@Repository
public interface ICourseResourceRepository extends JpaRepository<CourseResource,Integer>{
	@Query("select cr FROM CourseResource cr where cr.courseCaption=?1")
	List<CourseResource> findByCourseCaption(String courseCaption);

	@Query("select cr FROM CourseResource cr where cr.courseCaption=?1 and cr.xuhao=?2")
	CourseResource findByCourseCaptionAndXuhao(String caption, int xuhao);
	
	@Modifying
	@Transactional	
	@Query("delete from CourseResource cr where cr.courseCaption=?1 and cr.xuhao=?2")
	void deleteBycourseCaptionAndXuhao(String caption, int xuhao);
}
