/**
 * 
 */
package bao1.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import bao1.entity.Course;

/**
 * @author 27205
 *
 */
public interface testRepository extends JpaRepository<Course,Integer>{
	
}
