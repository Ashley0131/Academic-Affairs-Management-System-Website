package bao1.dao;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import bao1.entity.Course;
@Repository
public interface ICourseRepository extends JpaRepository<Course,String>{
	@Query("select c From Course c where c.caption=?1")
	public Course findBycaption(String caption);
	
	@Query("select c From Course c where c.teacherAccount=?1")
	public List<Course> findByteacherAccount(String teacherAccount);
	
	@Query("select c From Course c where c.sn=?1")
	public Course findBysn(String sn);
}
