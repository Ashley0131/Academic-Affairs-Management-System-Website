package bao1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import bao1.dao.IUserRepository;
import bao1.entity.User;

@Controller
public class DBAccessController {
	@Autowired
	private IUserRepository userRepository;
	@RequestMapping("/userList")
	@ResponseBody
	public String showUserInformation() {
		//访问数据库并获取所有用户
		List<User> users=userRepository.findAll();
		//组织要显示的字符串
		StringBuffer buf = new StringBuffer();
		buf.append("<table>");
		buf.append("   <th>ID</th>");
		buf.append("   <th>账户</th>");
		buf.append("   <th>密码</th>");
		//这里换行要用<br/>
		//buf.append("ID 账户 密码<br/>");
		for(int i=0;i<users.size();i++) {
			buf.append("   <tr>");
			buf.append("     <td>"+users.get(i).getId()+"</td>");
			buf.append("     <td>"+users.get(i).getAccount()+"</td>");
			buf.append("     <td>"+users.get(i).getPassword()+"</td>");
			buf.append("   </tr>");
		}
		buf.append("</table>");
		System.out.println(buf.toString());
		return buf.toString();
	}
}
