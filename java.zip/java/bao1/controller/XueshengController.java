package bao1.controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class XueshengController {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	//学生修改基本信息
	@RequestMapping("/xueshengxiugaijibenxinxi")
	public ModelAndView xueshengxiugaijibenxinxi(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("学生");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		/*int xuehao=(Integer)user.get("id");
		String sql="select * from student where id="+xuehao;
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);*/
		ModelAndView m=new ModelAndView("xueshengxiugaijibenxinxi");
		Map<String,Object> model = m.getModel();
		model.put("user", user);
		return m;
	}
	@RequestMapping(value="/xueshengxiuigaijibenxinxijieshu",method=RequestMethod.POST)
	@ResponseBody
	public ModelAndView xueshengxiugaijibenxinxijieshu(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("学生");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		int xuehao=(Integer)user.get("id");
		String sql="update student set sname='"+request.getParameter("name")+"',idcard_number='"+request.getParameter("shenfenzheng")
		+"',gender='"+request.getParameter("xingbie")+"',nation='"+request.getParameter("minzu")+"',origin='"+request.getParameter("jiguan")
		+"',domicile_place='"+request.getParameter("hujisuozaidi")+"',political_face='"+request.getParameter("zhengzhimianmao")+
		"',blood_type='"+request.getParameter("xuexing")+"',birthday='"+request.getParameter("chushengriqi")+"' where id="+xuehao;
		jdbcTemplate.execute(sql);
		session.removeAttribute("学生");
		sql="select * from student where id="+xuehao;
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		session.setAttribute("学生",sqlList.get(0));
		ModelAndView m=new ModelAndView("xueshengindex");
		Map<String,Object> model = m.getModel();
		model.put("curUser", sqlList.get(0));
		return m;
	}
	//学生修改账户信息
	@RequestMapping("/xueshengxiugaizhanghuxinxi")
	public ModelAndView xueshengxiugaizhanghuxinxi(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("学生");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		/*int xuehao=(Integer)user.get("id");
		String sql="select * from student where id="+xuehao;
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);*/
		ModelAndView m=new ModelAndView("xueshengxiugaizhanghuxinxi");
		Map<String,Object> model = m.getModel();
		model.put("user", user);
		return m;
	}
	@RequestMapping(value="/xueshengxiuigaizhanghuxinxijieshu",method=RequestMethod.POST)
	@ResponseBody
	public ModelAndView xueshengxiugaizhanghuxinxijieshu(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("学生");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		int xuehao=(Integer)user.get("id");
		String sql="update student set password='"+request.getParameter("mima")+"',phone='"+request.getParameter("lianxidianhua")
		+"',E_mail='"+request.getParameter("dianziyouxiang")+"',homeaddress='"+request.getParameter("jiatingzhuzhi")+"',qqid='"+request.getParameter("qqhao")
		+"',wechatid='"+request.getParameter("weixinhao")+"' where id="+xuehao;
		jdbcTemplate.execute(sql);
		session.removeAttribute("学生");
		sql="select * from student where id="+xuehao;
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		session.setAttribute("学生",sqlList.get(0));
		ModelAndView m=new ModelAndView("xueshengindex");
		Map<String,Object> model = m.getModel();
		model.put("curUser", sqlList.get(0));
		return m;
	}
	//学生查看学籍信息
	@RequestMapping("/xueshengchakanxuejixinxi")
	public ModelAndView xueshengchakanxuejixinxi(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("学生");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		int xuehao=(Integer)user.get("id");
		String sql="select * from stu_status_inf where sid="+xuehao;
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		ModelAndView m=new ModelAndView("xueshengchakanxuejixinxi");
		Map<String,Object> model = m.getModel();
		model.put("user", sqlList.get(0));
		return m;
	}
	@RequestMapping(value="/xueshengchakanxuejixinxifanhui",method=RequestMethod.POST)
	@ResponseBody
	public ModelAndView xueshengchakanxuejixinxifanhui(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("学生");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		ModelAndView m=new ModelAndView("xueshengindex");
		Map<String,Object> model = m.getModel();
		model.put("curUser", user);
		return m;
	}
	//学生选课
	@RequestMapping("/xueshengxuanke")
	public ModelAndView xueshengxuanke(String xuehao,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("学生");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		String sql="select * from started_course where sc_id not in(select sc_id from select_course where sid ="+user.get("id")+")";
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		if(sqlList.size()==0) {
			ModelAndView m=new ModelAndView("kong");
			Map<String,Object> model = m.getModel();
			model.put("curUser",user);
			return m;
		}
		for(Map<String,Object> ssql:sqlList) {
			sql="select coname from course where coid="+ssql.get("sc_id");
			List<Map<String,Object>> zhongjian=jdbcTemplate.queryForList(sql);
			ssql.put("kechengming", zhongjian.get(0).get("coname"));
			sql="select tname from teacher where id="+ssql.get("teacherid");
			zhongjian=jdbcTemplate.queryForList(sql);
			ssql.put("jiaoshiming", zhongjian.get(0).get("tname"));
		}
		ModelAndView m=new ModelAndView("xueshengxuanke");
		Map<String,Object> model = m.getModel();
		model.put("curUser", user);
		model.put("courseResources", sqlList);
		return m;
	}
	@RequestMapping("/xuanke")
	public ModelAndView xuanke(int sn,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("学生");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		int xuehao=(Integer)user.get("id");
		String sql="insert into select_course(sid,sc_id) values("+xuehao+","+sn+")";
		jdbcTemplate.execute(sql);
		ModelAndView m=new ModelAndView("xueshengindex");
		Map<String,Object> model = m.getModel();
		model.put("curUser",user);
		return m;
	}
	//学生课程评价
	@RequestMapping("/xueshengkechengpingjia")
	public ModelAndView xueshengkechengpingjia(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("学生");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		int xuehao=(Integer)user.get("id");
		String sql="select sc_id from select_course where sid="+xuehao;
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		if(sqlList.size()==0) {
			ModelAndView m=new ModelAndView("kong");
			Map<String,Object> model = m.getModel();
			model.put("curUser",user);
			return m;
		}
		for(Map<String,Object> ssql:sqlList) {
			sql="select coname from course where coid="+ssql.get("sc_id");
			List<Map<String,Object>> zhongjian=jdbcTemplate.queryForList(sql);
			ssql.put("kechengming", zhongjian.get(0).get("coname"));
			sql="select co_context_appraise,teaching_appraise from appraise where sid="+xuehao+" and sc_id="+ssql.get("sc_id");
			zhongjian=jdbcTemplate.queryForList(sql);
			if(zhongjian.size()==0) {
				ssql.put("kechengfen", "未评价");
				ssql.put("jiaoshifen", "未评价");
			}
			else {
				ssql.put("kechengfen", zhongjian.get(0).get("co_context_appraise"));
				ssql.put("jiaoshifen", zhongjian.get(0).get("teaching_appraise"));
			}
		}
		ModelAndView m=new ModelAndView("xueshengkechengpingjia");
		Map<String,Object> model = m.getModel();
		model.put("curUser", user);
		model.put("courseResources", sqlList);
		return m;
	}
	@RequestMapping("/xueshengpingjia")
	public ModelAndView xueshengpingjia(int sn,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("学生");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		int xuehao=(Integer)user.get("id");
		String sql="select * from course where coid="+sn;
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		ModelAndView m=new ModelAndView("xueshengpingjia");
		Map<String,Object> model = m.getModel();
		model.put("user", user);
		model.put("kecheng", sqlList.get(0));
		return m;
	}
	@RequestMapping("/xueshengpingjiajieshu")
	public ModelAndView xueshengpingjiajieshu(int sn,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("学生");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		int xuehao=(Integer)user.get("id");
		String sql="delete from appraise where sid="+xuehao+" and sc_id="+sn;
		jdbcTemplate.execute(sql);
		String kechengpingjia=request.getParameter("kechengpingjia");
		String jiaoshipingjia=request.getParameter("jiaoshipingjia");
		sql="insert into appraise(sid,sc_id,appraise_time,co_context_appraise,teaching_appraise) values("+
		xuehao+","+sn+",now(),+"+Integer.parseInt(kechengpingjia)+","+Integer.parseInt(jiaoshipingjia)+")";
		jdbcTemplate.execute(sql);
		ModelAndView m=new ModelAndView("xueshengindex");
		Map<String,Object> model = m.getModel();
		model.put("curUser",user);
		return m;
	}
	//学生已选课程查询
	@RequestMapping("/xueshengyixuankechengchaxun")
	public ModelAndView xueshengkaikekechengchaxun(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("学生");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		String sql="select * from started_course where sc_id  in(select sc_id from select_course where sid ="+user.get("id")+")";
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		if(sqlList.size()==0) {
			ModelAndView m=new ModelAndView("kong");
			Map<String,Object> model = m.getModel();
			model.put("curUser",user);
			return m;
		}
		for(Map<String,Object> ssql:sqlList) {
			sql="select coname from course where coid="+ssql.get("sc_id");
			List<Map<String,Object>> zhongjian=jdbcTemplate.queryForList(sql);
			ssql.put("kechengming", zhongjian.get(0).get("coname"));
			sql="select tname from teacher where id="+ssql.get("teacherid");
			zhongjian=jdbcTemplate.queryForList(sql);
			ssql.put("jiaoshiming", zhongjian.get(0).get("tname"));
		}
		ModelAndView m=new ModelAndView("xueshengyixuan");
		Map<String,Object> model = m.getModel();
		model.put("curUser", user);
		model.put("courseResources", sqlList);
		return m;
	}
	@RequestMapping("/tuixuan")
	public ModelAndView tuixuan(int sn,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("学生");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		int xuehao=(Integer)user.get("id");
		String sql="delete from select_course where sid="+xuehao+" and sc_id="+sn;
		jdbcTemplate.execute(sql);
		sql="delete from reserve_textbook where teid in(select teid from textbook where sc_id="+sn+")";
		jdbcTemplate.execute(sql);
		ModelAndView m=new ModelAndView("xueshengindex");
		Map<String,Object> model = m.getModel();
		model.put("curUser",user);
		return m;
	}
	//学生教材预订
	@RequestMapping("/xueshengjiaocaiyuding")
	public ModelAndView xueshengjiaocaiyuding(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("学生");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		int xuehao=(Integer)user.get("id");
		String sql="select * from textbook where sc_id in (select sc_id from select_course where sid="+xuehao+")";
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		if(sqlList.size()==0) {
			ModelAndView m=new ModelAndView("kong");
			Map<String,Object> model = m.getModel();
			model.put("curUser",user);
			return m;
		}
		for(Map<String,Object> ssql:sqlList) {
			sql="select coname from course where coid="+ssql.get("sc_id");
			List<Map<String,Object>> zhongjian=jdbcTemplate.queryForList(sql);
			ssql.put("kechengming", zhongjian.get(0).get("coname"));
			sql="select * from reserve_textbook where sid="+xuehao+" and teid="+ssql.get("teid");
			zhongjian=jdbcTemplate.queryForList(sql);
			if(zhongjian.size()==0)
				ssql.put("zhuangtai", "未订");
			else
				ssql.put("zhuangtai","已订");
		}
		ModelAndView m=new ModelAndView("xueshengjiaocaiyuding");
		Map<String,Object> model = m.getModel();
		model.put("curUser",user);
		model.put("courseResources", sqlList);
		return m;
	}
	//修改订书状态
	@RequestMapping("/xiugaidingshuzhuangtai")
	public ModelAndView xiugaidingshuzhuangtai(int sn,String zhuangtai,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("学生");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		int xuehao=(Integer)user.get("id");
		if(zhuangtai.equals("已订")) {
			String sql="delete from reserve_textbook where sid="+xuehao+" and teid="+sn;
			jdbcTemplate.execute(sql);
		}
		else {
			String sql="insert into reserve_textbook(sid,teid,reserve_time) values("+xuehao+","+sn+",now())";
			jdbcTemplate.execute(sql);
		}
		ModelAndView m=new ModelAndView("xueshengindex");
		Map<String,Object> model = m.getModel();
		model.put("curUser",user);
		return m;
	}
	//学生查看教室信息
	@RequestMapping("/xueshengchakanjiaoshixinxi")
	public ModelAndView xueshengchakanjiaoshixinxi(String xuehao,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("学生");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		String sql="select * from classroom_inf";
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		ModelAndView m=new ModelAndView("xueshengchakanjiaoshixinxi");
		Map<String,Object> model = m.getModel();
		model.put("curUser", user);
		model.put("courseResources", sqlList);
		return m;
	}
	//学生查看公告
	@RequestMapping("/xushengchakangonggao")
	public ModelAndView xushengchakangonggao(String xuehao,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("学生");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		String sql="select * from announcement where visible_range='全体学生'";
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		if(sqlList.size()==0) {
			ModelAndView m=new ModelAndView("kong");
			Map<String,Object> model = m.getModel();
			model.put("curUser",user);
			return m;
		}
		ModelAndView m=new ModelAndView("xueshengchakangonggao");
		Map<String,Object> model = m.getModel();
		model.put("curUser", user);
		model.put("courseResources", sqlList);
		return m;
	}
}
