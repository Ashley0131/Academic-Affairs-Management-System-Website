package bao1.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.swing.text.html.FormSubmitEvent.MethodType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import bao1.dao.ICourseRepository;
import bao1.dao.ICourseResourceRepository;
import bao1.entity.Course;
import bao1.entity.CourseResource;
import bao1.entity.User;

@Controller
@RestController
public class CourseController {
	
	@Autowired
	private ICourseResourceRepository courseResourceRepository;
	@Autowired
	private ICourseRepository courseRepository;
	//教学资源
	@RequestMapping("/download")
	public ModelAndView download(String sn,HttpServletRequest request,HttpSession session) {
		User user=(User)session.getAttribute("user");
		if(user==null) {
			ModelAndView m=new ModelAndView("login");
			return m;
		}
		if(sn==null)sn="1";
		List<Course> courses=courseRepository.findAll();
		List<CourseResource> res=courseResourceRepository.findByCourseCaption(courseRepository.findBysn(sn).getCaption());
		ModelAndView m=new ModelAndView("download");
		m.getModel().put("courses", courses);
		m.getModel().put("curCourse", courseRepository.findBysn(sn));
		m.getModel().put("courseResources", res);
		m.getModel().put("curUser", user);
		return m;
	}
	
	
	//资源管理
	@RequestMapping("/resedit")
	public ModelAndView resedit(String sn,HttpServletRequest request,HttpSession session) {
		
		User user=(User)session.getAttribute("user");
		if(user==null) {
			ModelAndView m=new ModelAndView("login");
			return m;
		}
		if(sn==null)sn="1";
		List<Course> courses=courseRepository.findAll();
		List<CourseResource> res=courseResourceRepository.findByCourseCaption(courseRepository.findBysn(sn).getCaption());
		ModelAndView m=new ModelAndView("resedit");
		m.getModel().put("courses", courses);
		m.getModel().put("curCourse", courseRepository.findBysn(sn));
		m.getModel().put("courseResources", res);
		m.getModel().put("curUser", user);
		return m;
	}
	
	@RequestMapping(value="/resupdate",method=RequestMethod.POST)
	public ModelAndView resupdate(@RequestParam("file") MultipartFile file,HttpServletRequest request,HttpSession session) {
		String courseno=request.getParameter("courseno");
		String xuhao=request.getParameter("xuhao");
		String title=request.getParameter("title");
		String description=request.getParameter("description");
		
		Course curCourse = courseRepository.getOne(courseno);
		if(curCourse == null) {
			ModelAndView eMV = new ModelAndView("error");
			eMV.getModel().put("errorTitle", "更新失败");
			eMV.getModel().put("errorContent", "课程编号无效:"+courseno);
			return eMV;
		}
		//保存文件
		String filename = "";
		try {
			filename = saveFile(file,curCourse.getPath(),xuhao);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			ModelAndView eMV = new ModelAndView("error");
			eMV.getModel().put("errorTitle", "更新失败");
			eMV.getModel().put("errorContent", "保存文件失败:"+e.getMessage());
			return eMV;
		}
		
		//创建新的课程资源记录
		CourseResource cr = new CourseResource();
		
		//将客户端传过来的属性给cr赋值
		cr.setXuhao(Integer.parseInt(xuhao));
		cr.setDescription(description);
		cr.setTitle(title);
		cr.setCourseCaption(curCourse.getCaption());
		cr.setPptFilename(filename);
		
		//保存
		courseResourceRepository.saveAndFlush(cr);
		
		//重定向到资源编辑页面
		return new ModelAndView("forward:/resedit");
			
	}
	
	@Value("${course.resource.path}") 
	private String courseresourcePath;
	
	private String saveFile(MultipartFile file,String path,String xh) throws Exception{
		if (file.isEmpty()) {
			return "";
		}
		
		String orginFilename = file.getOriginalFilename();
		int p = orginFilename.lastIndexOf(".");
		String filename = xh + orginFilename.substring(p,orginFilename.length());		
		File f = new File(courseresourcePath+path+"/download/"+filename);
		System.out.println(courseresourcePath+path+"/download/"+filename);
		if(!f.exists())
			f.createNewFile();
		
		BufferedOutputStream out = new BufferedOutputStream(
                new FileOutputStream(f));
        out.write(file.getBytes());
        out.flush();
        out.close();
		
        return filename;
	}
	
	
	@RequestMapping("/resdelete")
    public ModelAndView resdelete(String sn, int resxuhao,HttpSession session) {
		//检查当前用户是否已经登陆 
		User user = (User) session.getAttribute("user");
		if(user == null) {//如果没有登陆，则跳转到登陆页面去
			return new ModelAndView("forward:/login");
		}
		
		//查找当前课程
		Course curCourse = courseRepository.findBysn(sn);
		if(curCourse == null) {
			ModelAndView eMV = new ModelAndView("error");
			eMV.getModel().put("errorTitle", "删除失败");
			eMV.getModel().put("errorContent", "当前课程编号不存在:"+sn);			
		}
		
		//删除特定课程名称和资源序号的资源项
		courseResourceRepository.deleteBycourseCaptionAndXuhao(curCourse.getCaption(),resxuhao);
		
		//重定向到资源编辑页面
		return new ModelAndView("forward:/resedit");
	}
	
}
