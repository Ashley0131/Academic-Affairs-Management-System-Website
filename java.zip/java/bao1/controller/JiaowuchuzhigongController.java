package bao1.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class JiaowuchuzhigongController {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	//师资管理
	@RequestMapping("/jiaowuchuzhigongshiziguanli")
	public ModelAndView jiaowuchuzhigongshiziguanli(String xuehao,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教务处职工");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		
		String sql="select * from teacher";
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		ModelAndView m=new ModelAndView("jiaowuchuzhigongshiziguanli");
		Map<String,Object> model = m.getModel();
		model.put("curUser", user);
		model.put("courseResources", sqlList);
		return m;
	}
	@RequestMapping("/jiaowuchuzhigongshiziguanliyemian")
	public ModelAndView jiaowuchuzhigongshiziguanliyemian(int xuehao,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教务处职工");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		String sql="select * from faculty_inf where tid="+xuehao;
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		ModelAndView m=new ModelAndView("jiaowuchuzhigongshiziguanliyemian");
		Map<String,Object> model = m.getModel();
		model.put("guanliyuan", user);
		model.put("user", sqlList.get(0));
		return m;
	}
	@RequestMapping(value="/jiaowuchuzhigongxiugaishiziguanlijieshu",method=RequestMethod.POST)
	@ResponseBody
	public ModelAndView jiaowuchuzhigongshiziguanlijieshu(int xuehao,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教务处职工");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		String sql="select deid from department where dename='"+request.getParameter("department")+"'";
		
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		int deid=(Integer)sqlList.get(0).get("deid");
		sql="update teacher set graduate_time='"+request.getParameter("graduate_time")+"',graduate_school='"+request.getParameter("graduate_school")+"',major_direction='"+request.getParameter("major_direction")
		+"',appointments_time='"+request.getParameter("appointments_time")+"',faculty_status='"+request.getParameter("faculty_status")+"',check_register_status='"+request.getParameter("check_register_status")
		+"',highest_education='"+request.getParameter("highest_education")+"',departmentid="+deid+" where id="+xuehao;
		jdbcTemplate.execute(sql);
		ModelAndView m=new ModelAndView("jiaowuchuzhigongindex");
		Map<String,Object> model = m.getModel();
		model.put("curUser", user);
		return m;
	}
	//教务处职工学籍管理
	@RequestMapping("/jiaowuchuzhigongxuejiguanli")
	public ModelAndView jiaowuchuzhigongxuejiguanli(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教务处职工");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		
		String sql="select * from student";
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		ModelAndView m=new ModelAndView("jiaowuchuzhigongxuejiguanli");
		Map<String,Object> model = m.getModel();
		model.put("curUser", user);
		model.put("courseResources", sqlList);
		return m;
	}
	//教务处职工学籍管理页面
	@RequestMapping("/jiaowuchuzhigongxuejiguanliyemian")
	public ModelAndView jiaowuchuzhigongxuejiguanliyemian(String xuehao,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教务处职工");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		int xuehao1=Integer.parseInt(xuehao.substring(0,1)+xuehao.substring(2));
		String sql="select * from stu_status_inf where sid="+xuehao1;
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		ModelAndView m=new ModelAndView("jiaowuchuzhigongxuejiguanliyemian");
		Map<String,Object> model = m.getModel();
		model.put("guanliyuan", user);
		model.put("user", sqlList.get(0));
		return m;
	}
	//教务处职工学籍管理结束
	@RequestMapping(value="/jiaowuchuzhigongxuejiguanlijieshu",method=RequestMethod.POST)
	@ResponseBody
	public ModelAndView jiaowuchuzhigongxuejiguanlijieshu(String xuehao,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教务处职工");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		int xuehao1=Integer.parseInt(xuehao.substring(0,1)+xuehao.substring(2));
		String sql="select classid from class where classname='"+request.getParameter("class")+"' and gradenumber="+Integer.parseInt(request.getParameter("gradenumber"));
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		int classid=(Integer)sqlList.get(0).get("classid");
		sql="update student set classid="+classid+",student_status='"+request.getParameter("student_status")+"',check_register_status='"+request.getParameter("check_register_status")
		+"' where id="+xuehao1;
		jdbcTemplate.execute(sql);
		ModelAndView m=new ModelAndView("jiaowuchuzhigongindex");
		Map<String,Object> model = m.getModel();
		model.put("curUser", user);
		return m;
	}
	//教务处职工教室管理
	@RequestMapping("/jiaowuchuzhigongjiaoshiguanli")
	public ModelAndView jiaowuchuzhigongjiaoshiguanli(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教务处职工");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		
		String sql="select * from classroom";
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		ModelAndView m=new ModelAndView("jiaowuchuzhigongjiaoshiguanli");
		Map<String,Object> model = m.getModel();
		model.put("curUser", user);
		model.put("courseResources", sqlList);
		return m;
	}
	//教务处职工教室管理页面
	@RequestMapping("/jiaowuchuzhigongjiaoshiguanliyemian")
	public ModelAndView jiaowuchuzhigongjiaoshiguanliyemian(int xuehao,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教务处职工");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		String sql="select * from classroom where clid="+xuehao;
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		ModelAndView m=new ModelAndView("jiaowuchuzhigongjiaoshiguanliyemian");
		Map<String,Object> model = m.getModel();
		model.put("jiaowuchuzhigong", user);
		model.put("user", sqlList.get(0));
		return m;
	}
	//教务处职工教室管理结束
	@RequestMapping(value="/jiaowuchuzhigongjiaoshiguanlijieshu",method=RequestMethod.POST)
	@ResponseBody
	public ModelAndView jiaowuchuzhigongjiaoshiguanlijieshu(int xuehao,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教务处职工");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		String sql="insert manage_classroom(ac_reg_staff_id,classroomid)values("+(Integer)user.get("id")+",101)";
		jdbcTemplate.execute(sql);
		sql="update classroom set reservation_status='"+request.getParameter("reservation_status")+"' where clid="+xuehao;
		jdbcTemplate.execute(sql);
		ModelAndView m=new ModelAndView("jiaowuchuzhigongindex");
		Map<String,Object> model = m.getModel();
		model.put("curUser", user);
		return m;
	}
	//教务处职工发布公告
	@RequestMapping("/jiaowuchuzhigongfabugonggao")
	public ModelAndView jiaowuchuzhigongfabugonggao(String xuehao,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教务处职工");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		ModelAndView m=new ModelAndView("jiaowuchuzhigongfabugonggao");
		Map<String,Object> model = m.getModel();
		model.put("user", user);
		return m;
	}
	@RequestMapping(value="/jiaowuchuzhigongfabugonggaojieshu",method=RequestMethod.POST)
	@ResponseBody
	public ModelAndView jiaowuchuzhigongfabugonggaojieshu(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教务处职工");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		int xuehao=(Integer)user.get("id");
		String sql="select annouid from announcement";
		List<Map<String,Object>> a=jdbcTemplate.queryForList(sql);
		int annouid=0;
		for(Map<String,Object> t:a) {
			annouid=Math.max(annouid,(Integer)t.get("annouid"));
		}
		annouid++;
		sql="insert into announcement(annouid,annoutitle,publishtime,content,visible_range,modify_time,ac_reg_staff_id)"
				+ "values("+annouid+",'"+request.getParameter("annoutitle")+"',now()"
				+",'"+request.getParameter("content")
				+"','"+request.getParameter("visible_range")+"',now(),"+xuehao+")";
		jdbcTemplate.execute(sql);
		ModelAndView m=new ModelAndView("jiaowuchuzhigongindex");
		Map<String,Object> model = m.getModel();
		model.put("curUser", user);
		return m;
	}
	//教务处职工管理公告
	@RequestMapping("/jiaowuchuzhigongguanligonggao")
	public ModelAndView jiaowuchuzhigongguanligonggao(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教务处职工");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		
		String sql="select * from announcement";
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		ModelAndView m=new ModelAndView("jiaowuchuzhigonggonggaoguanli");
		Map<String,Object> model = m.getModel();
		model.put("curUser", user);
		model.put("courseResources", sqlList);
		return m;
	}
	//教务处职工公告管理页面
	@RequestMapping("/jiaowuchuzhigonggonggaoguanliyemian")
	public ModelAndView jiaowuchuzhigonggonggaoguanliyemian(int xuehao,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教务处职工");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		String sql="select * from announcement where annouid="+xuehao;
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		ModelAndView m=new ModelAndView("jiaowuchuzhigonggonggaoguanliyemian");
		Map<String,Object> model = m.getModel();
		model.put("jiaowuchuzhigong", user);
		model.put("user", sqlList.get(0));
		return m;
	}
	//教务处职工公告管理结束
	@RequestMapping(value="/jiaowuchuzhigonggonggaoguanlijieshu",method=RequestMethod.POST)
	@ResponseBody
	public ModelAndView jiaowuchuzhigonggonggaoguanlijieshu(int xuehao,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教务处职工");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		String sql="insert manage_announcement(ac_reg_staff_id,annouid)values("+(Integer)user.get("id")+",1)";
		jdbcTemplate.execute(sql);
		sql="update announcement set annoutitle='"+request.getParameter("annoutitle")+"',content='"+request.getParameter("content")+"',visible_range='"+request.getParameter("visible_range")
		+"',modify_time=now(),ac_reg_staff_id="+(Integer)user.get("id")+" where annouid="+xuehao;
		jdbcTemplate.execute(sql);
		ModelAndView m=new ModelAndView("jiaowuchuzhigongindex");
		Map<String,Object> model = m.getModel();
		model.put("curUser", user);
		return m;
	}
	//教务处职工修改账户信息
	@RequestMapping("/jiaowuchuzhigongxiugaizhanghuxinxi")
	public ModelAndView jiaowuchuzhigongxiugaizhanghuxinxi(String xuehao,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教务处职工");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		ModelAndView m=new ModelAndView("jiaowuchuzhigongxiugaizhanghuxinxi");
		Map<String,Object> model = m.getModel();
		model.put("user", user);
		return m;
	}
	@RequestMapping(value="/jiaowuchuzhigongxiugaizhanghuxinxijieshu",method=RequestMethod.POST)
	@ResponseBody
	public ModelAndView guanliyuanxiugaizhanghuxinxijieshu(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教务处职工");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		int xuehao=(Integer)user.get("id");
		String sql="update ac_reg_staff set password='"+request.getParameter("mima")+"' where id="+xuehao;
		jdbcTemplate.execute(sql);
		session.removeAttribute("教务处职工");
		sql="select * from ac_reg_staff where id="+xuehao;
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		session.setAttribute("教务处职工",sqlList.get(0));
		ModelAndView m=new ModelAndView("jiaowuchuzhigongindex");
		Map<String,Object> model = m.getModel();
		model.put("curUser", sqlList.get(0));
		return m;
	}
	//教务处职工开课课程设计
	@RequestMapping("/jiaowuchuzhigongkaikekechengsheji")
	public ModelAndView jiaowuchuzhigongkaikekechengsheji(String xuehao,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教务处职工");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		
		String sql="select * from course where coid not in(select coid from started_course)";
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		if(sqlList.size()==0) {
			ModelAndView m=new ModelAndView("jiaowuchuzhigongkong");
			Map<String,Object> model = m.getModel();
			model.put("curUser",user);
			return m;
		}
		ModelAndView m=new ModelAndView("jiaowuchuzhigongkaikekechengsheji");
		Map<String,Object> model = m.getModel();
		model.put("curUser", user);
		model.put("courseResources", sqlList);
		return m;
	}
	//教务处职工开课课程设计页面
		@RequestMapping("/jiaowuchuzhigongkaikekechengshejiyemian")
		public ModelAndView jiaowuchuzhigongkaikekechengshejiyemian(int xuehao,HttpServletRequest request,HttpSession session) {
			Map<String,Object> user=(Map<String,Object>)session.getAttribute("教务处职工");
			if(user==null) {
				ModelAndView m=new ModelAndView("ceshi2");
				return m;
			}
			ModelAndView m=new ModelAndView("jiaowuchuzhigongkaikekechengshejiyemian");
			Map<String,Object> model = m.getModel();
			model.put("jiaowuchuzhigong", user);
			model.put("user", xuehao);
			return m;
		}
		//教务处职工开课课程设计结束
		@RequestMapping(value="/jiaowuchuzhigongkaikekechengshejijieshu",method=RequestMethod.POST)
		@ResponseBody
		public ModelAndView jiaowuchuzhigongkaikekechengshejijieshu(int xuehao,HttpServletRequest request,HttpSession session) {
			Map<String,Object> user=(Map<String,Object>)session.getAttribute("教务处职工");
			if(user==null) {
				ModelAndView m=new ModelAndView("ceshi2");
				return m;
			}
			int gonghao=(Integer)user.get("id");
			String sql="insert into started_course(sc_id,open_semester,open_study_year,classroomid,select_capacity,b_to_e_week,weekday,beginsection,"
					+ "sectionnum,teacherid,total_study_hours,open_ac_reg_staffid,coid)"
					+ "values("+xuehao+",'"+request.getParameter("open_semester")+"','"
					+request.getParameter("open_study_year")+"',"+
					Integer.parseInt(request.getParameter("classroomid"))+","+
					Integer.parseInt(request.getParameter("select_capacity"))+",'"+
					request.getParameter("b_to_e_week")+"','"+
					request.getParameter("weekday")+"',"+
					Integer.parseInt(request.getParameter("beginsection"))+","+
					Integer.parseInt(request.getParameter("sectionnum"))+","+
					Integer.parseInt(request.getParameter("teacherid"))+","+
					Integer.parseInt(request.getParameter("total_study_hours"))+","+gonghao+","+xuehao+")";
			jdbcTemplate.execute(sql);
			ModelAndView m=new ModelAndView("jiaowuchuzhigongindex");
			Map<String,Object> model = m.getModel();
			model.put("curUser", user);
			return m;
		}
}
