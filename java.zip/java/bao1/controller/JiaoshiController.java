package bao1.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class JiaoshiController {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	//教师修改基本信息
	@RequestMapping("/jiaoshixiugaijibenxinxi")
	public ModelAndView jiaoshixiugaijibenxinxi(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教师");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		ModelAndView m=new ModelAndView("jiaoshixiugaijibenxinxi");
		Map<String,Object> model = m.getModel();
		model.put("user", user);
		return m;
	}
	//修改基本信息结束
	@RequestMapping(value="/jiaoshixiuigaijibenxinxijieshu",method=RequestMethod.POST)
	@ResponseBody
	public ModelAndView jiaoshixiugaijibenxinxijieshu(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教师");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		int xuehao=(Integer)user.get("id");
		String sql="update teacher set tname='"+request.getParameter("name")+"',idcard_number='"+request.getParameter("shenfenzheng")
		+"',gender='"+request.getParameter("xingbie")+"',nation='"+request.getParameter("minzu")+"',origin='"+request.getParameter("jiguan")
		+"',domicile_place='"+request.getParameter("hujisuozaidi")+"',political_face='"+request.getParameter("zhengzhimianmao")+
		"',blood_type='"+request.getParameter("xuexing")+"',birthday='"+request.getParameter("chushengriqi")+"' where id="+xuehao;
		jdbcTemplate.execute(sql);
		session.removeAttribute("教师");
		sql="select * from teacher where id="+xuehao;
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		session.setAttribute("教师",sqlList.get(0));
		ModelAndView m=new ModelAndView("jiaoshiindex");
		Map<String,Object> model = m.getModel();
		model.put("curUser", sqlList.get(0));
		return m;
	}
	//教师修改账户信息
	@RequestMapping("/jiaoshixiugaizhanghuxinxi")
	public ModelAndView jiaoshixiugaizhanghuxinxi(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教师");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		ModelAndView m=new ModelAndView("jiaoshixiugaizhanghuxinxi");
		Map<String,Object> model = m.getModel();
		model.put("user", user);
		return m;
	}
	@RequestMapping(value="/jiaoshixiuigaizhanghuxinxijieshu",method=RequestMethod.POST)
	@ResponseBody
	public ModelAndView jiaoshixiuigaizhanghuxinxijieshu(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教师");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		int xuehao=(Integer)user.get("id");
		String sql="update teacher set password='"+request.getParameter("mima")+"',phone='"+request.getParameter("lianxidianhua")
		+"',E_mail='"+request.getParameter("dianziyouxiang")+"',homeaddress='"+request.getParameter("jiatingzhuzhi")+"',qqid='"+request.getParameter("qqhao")
		+"',wechatid='"+request.getParameter("weixinhao")+"' where id="+xuehao;
		jdbcTemplate.execute(sql);
		session.removeAttribute("教师");
		sql="select * from teacher where id="+xuehao;
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		session.setAttribute("教师",sqlList.get(0));
		ModelAndView m=new ModelAndView("jiaoshiindex");
		Map<String,Object> model = m.getModel();
		model.put("curUser", sqlList.get(0));
		return m;
	}
	//教师查看师资信息
	@RequestMapping("/jiaoshichakanshizixinxi")
	public ModelAndView jiaoshichakanshizixinxi(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教师");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		int xuehao=(Integer)user.get("id");
		String sql="select * from faculty_inf where tid="+xuehao;
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		ModelAndView m=new ModelAndView("jiaoshichakanshizixinxi");
		Map<String,Object> model = m.getModel();
		model.put("user", sqlList.get(0));
		return m;
	}
	//教师查看基本信息返回
	@RequestMapping(value="/jiaoshichakanshizixinxifanhui",method=RequestMethod.POST)
	@ResponseBody
	public ModelAndView jiaoshichakanshizixinxifanhui(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教师");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		ModelAndView m=new ModelAndView("jiaoshiindex");
		Map<String,Object> model = m.getModel();
		model.put("curUser", user);
		return m;
	}
	//教师成绩修改
	@RequestMapping("/jiaoshichengjixiugai")
	public ModelAndView jiaoshichengjixiugai(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教师");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		int xuehao=(Integer)user.get("id");
		String sql="select * from stu_grades where started_courseid in (select sc_id from started_course where teacherid ="+xuehao+")";
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		if(sqlList.size()==0) {
			ModelAndView m=new ModelAndView("jiaoshikong");
			Map<String,Object> model = m.getModel();
			model.put("curUser",user);
			return m;
		}
		int i;
		for(i=0;i<sqlList.size();i++) {//{Map<String,Ojbect> ssql:sqlList
			Map<String,Object> ssql=sqlList.get(i);
			sql="select coname from course where coid="+ssql.get("started_courseid");
			List<Map<String, Object>> zhongjian=jdbcTemplate.queryForList(sql);
			ssql.put("kechengming", zhongjian.get(0).get("coname"));
			sql="select sname from student where id="+ssql.get("sid");
			zhongjian=jdbcTemplate.queryForList(sql);
			ssql.put("xueshengming", zhongjian.get(0).get("sname"));
		}
		ModelAndView m=new ModelAndView("jiaoshichengjixiugai");
		Map<String,Object> model = m.getModel();
		model.put("curUser", user);
		model.put("courseResources", sqlList);
		return m;
	}
	//教师成绩修改页面
	@RequestMapping("/jiaoshichengjixiugaiyemian")
	public ModelAndView jiaoshichengjixiugaiyemian(String xuehao,int kechenghao,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教师");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		ModelAndView m=new ModelAndView("jiaoshichengjixiugaiyemian");
		Map<String,Object> model = m.getModel();
		int xuehao1=Integer.parseInt(xuehao.substring(0,1)+xuehao.substring(2));
		model.put("user", user);
		model.put("xuehao", xuehao1);
		model.put("kechenghao",kechenghao);
		return m;
	}
	//教师修改结束
	@RequestMapping("/jiaoshixiugaijieshu")
	public ModelAndView jiaoshixiugaijieshu(String xuehao,int kechenghao,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教师");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		int xuehao1=Integer.parseInt(xuehao.substring(0,1)+xuehao.substring(2));
		String fenshu=request.getParameter("fenshu");
		String sql="update stu_grades set grades="+Double.parseDouble(fenshu)+" where sid="+xuehao1+" and started_courseid="+kechenghao;
		jdbcTemplate.execute(sql);
		ModelAndView m=new ModelAndView("jiaoshiindex");
		Map<String,Object> model = m.getModel();
		model.put("curUser",user);
		return m;
	}
	//教师成绩录入
	@RequestMapping("/jiaoshichengjiluru")
	public ModelAndView jiaoshichengjiluru(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教师");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		int xuehao=(Integer)user.get("id");
		String sql="select * from select_course where sc_id in (select sc_id from started_course where teacherid ="+xuehao+")";
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		if(sqlList.size()==0) {
			ModelAndView m=new ModelAndView("jiaoshikong");
			Map<String,Object> model = m.getModel();
			model.put("curUser",user);
			return m;
		}
		int i;
		for(i=0;i<sqlList.size();i++) {//{Map<String,Ojbect> ssql:sqlList
			sql="select sid from stu_grades where sid="+sqlList.get(i).get("sid")+" and started_courseid="+sqlList.get(i).get("sc_id");
			List<Map<String,Object>> zhongjian=jdbcTemplate.queryForList(sql);
			if(zhongjian.size()!=0) {
				sqlList.remove(i);
				i--;
				continue;
			}
			Map<String,Object> ssql=sqlList.get(i);
			sql="select coname from course where coid="+ssql.get("sc_id");
			zhongjian=jdbcTemplate.queryForList(sql);
			ssql.put("kechengming", zhongjian.get(0).get("coname"));
			sql="select sname from student where id="+ssql.get("sid");
			zhongjian=jdbcTemplate.queryForList(sql);
			ssql.put("xueshengming", zhongjian.get(0).get("sname"));
		}
		if(sqlList.size()==0) {
			ModelAndView m=new ModelAndView("jiaoshikong");
			Map<String,Object> model = m.getModel();
			model.put("curUser",user);
			return m;
		}
		ModelAndView m=new ModelAndView("jiaoshichengjiluru");
		Map<String,Object> model = m.getModel();
		model.put("curUser", user);
		model.put("courseResources", sqlList);
		return m;
	}
	//教师打分
	@RequestMapping("/jiaoshidafen")
	public ModelAndView jiaoshidafen(String xuehao,int kechenghao,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教师");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		ModelAndView m=new ModelAndView("jiaoshidafen");
		Map<String,Object> model = m.getModel();
		int xuehao1=Integer.parseInt(xuehao.substring(0,1)+xuehao.substring(2));
		model.put("user", user);
		model.put("xuehao", xuehao1);
		model.put("kechenghao",kechenghao);
		return m;
	}
	//教师打分结束
	@RequestMapping("/jiaoshidafenjieshu")
	public ModelAndView jiaoshidafenjieshu(String xuehao,int kechenghao,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教师");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		int xuehao1=Integer.parseInt(xuehao.substring(0,1)+xuehao.substring(2));
		int jiaoshihao=(Integer)user.get("id");
		String fenshu=request.getParameter("fenshu");
		String sql="insert into stu_grades(sid,started_courseid,grades,enter_grade_tea) values("+
		xuehao1+","+kechenghao+","+Double.parseDouble(fenshu)+",+"+jiaoshihao+")";
		jdbcTemplate.execute(sql);
		ModelAndView m=new ModelAndView("jiaoshiindex");
		Map<String,Object> model = m.getModel();
		model.put("curUser",user);
		return m;
	}
	//教师开课课程查询
	@RequestMapping("/jiaoshikaikekechengchaxun")
	public ModelAndView jiaoshikaikekechengchaxun(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教师");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		int xuehao=(Integer)user.get("id");
		String sql="select * from started_course where teacherid = "+xuehao;
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		if(sqlList.size()==0) {
			ModelAndView m=new ModelAndView("kong");
			Map<String,Object> model = m.getModel();
			model.put("curUser",user);
			return m;
		}
		for(Map<String,Object> ssql:sqlList) {
			sql="select coname from course where coid="+ssql.get("coid");
			List<Map<String,Object>> zhongjian=jdbcTemplate.queryForList(sql);
			ssql.put("kechengming", zhongjian.get(0).get("coname"));
		}
		ModelAndView m=new ModelAndView("jiaoshikaikekechengchaxun");
		Map<String,Object> model = m.getModel();
		model.put("curUser", user);
		model.put("courseResources", sqlList);
		return m;
	}
	//教师预约教室
	@RequestMapping("/jiaoshiyuyuejiaoshi")
	public ModelAndView jiaoshiyuyuejiaoshi(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教师");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		
		String sql="select * from classroom_inf";
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		if(sqlList.size()==0) {
			ModelAndView m=new ModelAndView("jiaoshikong");
			Map<String,Object> model = m.getModel();
			model.put("curUser",user);
			return m;
		}
		ModelAndView m=new ModelAndView("jiaoshiyuyuejiaoshi");
		Map<String,Object> model = m.getModel();
		model.put("curUser", user);
		model.put("courseResources", sqlList);
		return m;
	}
	//教师点击预约
	@RequestMapping("/jiaoshiyuyuejiaoshiyemian")
	public ModelAndView jiaoshiyuyuejiaoshiyemian(int classroomid,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教师");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		ModelAndView m=new ModelAndView("jiaoshiyuyuejiaoshiyemian");
		Map<String,Object> model = m.getModel();
		model.put("user", user);
		model.put("classroomid", classroomid);
		return m;
	}
	//教师预约教室结束
	@RequestMapping("/jiaoshiyuyuejiaoshijieshu")
	public ModelAndView jiaoshiyuyuejiaoshijieshu(int classroomid,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("教师");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		int jiaoshihao=(Integer)user.get("id");
		String sql="select rcid from reserve_classroom";
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		int rcid=0;
		for(Map<String,Object> listt:sqlList) {
			rcid=Math.max(rcid,(Integer)listt.get("rcid"));
		}
		rcid++;
		sql="insert into reserve_classroom(rcid,reserve_time,reserve_use_time,teacherid,classroomid) "
		+ "values("+
		rcid+",now(),'"+request.getParameter("yuyueshijian")+"',"+jiaoshihao+","+classroomid+")";
		jdbcTemplate.execute(sql);
		ModelAndView m=new ModelAndView("jiaoshiindex");
		Map<String,Object> model = m.getModel();
		model.put("curUser",user);
		return m;
	}
	
	//教师查看教室信息
		@RequestMapping("/jiaoshichakanjiaoshixinxi")
		public ModelAndView jiaoshichakanjiaoshixinxi(String xuehao,HttpServletRequest request,HttpSession session) {
			Map<String,Object> user=(Map<String,Object>)session.getAttribute("教师");
			if(user==null) {
				ModelAndView m=new ModelAndView("ceshi2");
				return m;
			}
			
			String sql="select * from classroom_inf";
			List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
			if(sqlList.size()==0) {
				ModelAndView m=new ModelAndView("jiaoshikong");
				Map<String,Object> model = m.getModel();
				model.put("curUser",user);
				return m;
			}
			ModelAndView m=new ModelAndView("jiaoshichakanjiaoshixinxi");
			Map<String,Object> model = m.getModel();
			model.put("curUser", user);
			model.put("courseResources", sqlList);
			return m;
		}
		//教师查看公告
		@RequestMapping("/jiaoshichakangonggao")
		public ModelAndView jiaoshichakangonggao(String xuehao,HttpServletRequest request,HttpSession session) {
			Map<String,Object> user=(Map<String,Object>)session.getAttribute("教师");
			if(user==null) {
				ModelAndView m=new ModelAndView("ceshi2");
				return m;
			}
			String sql="select * from announcement where visible_range='全体教师'";
			List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
			if(sqlList.size()==0) {
				ModelAndView m=new ModelAndView("jiaoshikong");
				Map<String,Object> model = m.getModel();
				model.put("curUser",user);
				return m;
			}
			ModelAndView m=new ModelAndView("jiaoshichakangonggao");
			Map<String,Object> model = m.getModel();
			model.put("curUser", user);
			model.put("courseResources", sqlList);
			return m;
		}
}
