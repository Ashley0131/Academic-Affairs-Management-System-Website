package bao1.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class GuanliyuanController {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	//管理员管理教务处职工
	@RequestMapping("/guanlijiaowuchuzhigong")
	public ModelAndView guanlijiaowuchuzhigong(String xuehao,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("管理员");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		
		String sql="select * from ac_reg_staff";
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		ModelAndView m=new ModelAndView("guanlijiaowuchuzhigong");
		Map<String,Object> model = m.getModel();
		model.put("curUser", user);
		model.put("courseResources", sqlList);
		return m;
	}
	@RequestMapping("/guanlijiaowuchuzhigongyemian")
	public ModelAndView guanlijiaowuchuzhigongyemian(int xuehao,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("管理员");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		String sql="select * from ac_reg_staff where id="+xuehao;
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		ModelAndView m=new ModelAndView("guanlijiaowuchuzhigongyemian");
		Map<String,Object> model = m.getModel();
		model.put("guanliyuan", user);
		model.put("user", sqlList.get(0));
		return m;
	}
	@RequestMapping(value="/guanlijiaowuchuzhigongjieshu")
	@ResponseBody
	public ModelAndView guanlijiaowuchuzhigongjieshu(int xuehao,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("管理员");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		String sql="update ac_reg_staff set id="+request.getParameter("xuehao")+",password='"+request.getParameter("mima")+"' where id="+xuehao;
		jdbcTemplate.execute(sql);
		String sqll="insert manage_staff_account_inf(administerid,ac_reg_staff_id)values("+(Integer)user.get("id")+",2)";
		jdbcTemplate.execute(sqll);
		ModelAndView m=new ModelAndView("guanliyuanindex");
		Map<String,Object> model = m.getModel();
		model.put("curUser", user);
		return m;
	}
	//管理教师
	@RequestMapping("/guanlijiaoshi")
	public ModelAndView guanlijiaoshi(String xuehao,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("管理员");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		
		String sql="select * from teacher";
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		ModelAndView m=new ModelAndView("guanlijiaoshi");
		Map<String,Object> model = m.getModel();
		model.put("curUser", user);
		model.put("courseResources", sqlList);
		return m;
	}
	@RequestMapping("/guanlijiaoshiyemian")
	public ModelAndView guanlijiaoshiyemian(int xuehao,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("管理员");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		String sql="select * from teacher where id="+xuehao;
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		ModelAndView m=new ModelAndView("guanlijiaoshiyemian");
		Map<String,Object> model = m.getModel();
		model.put("guanliyuan", user);
		model.put("user", sqlList.get(0));
		return m;
	}
	@RequestMapping(value="/guanlijiaoshijieshu")
	@ResponseBody
	public ModelAndView guanlijiaoshijieshu(int xuehao,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("管理员");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		String sql="update teacher set id="+request.getParameter("xuehao")+",password='"+request.getParameter("mima")+"',phone='"+request.getParameter("lianxidianhua")
		+"',E_mail='"+request.getParameter("dianziyouxiang")+"',homeaddress='"+request.getParameter("jiatingzhuzhi")+"',qqid='"+request.getParameter("qqhao")
		+"',wechatid='"+request.getParameter("weixinhao")+"' where id="+xuehao;
		jdbcTemplate.execute(sql);
		String sqll="insert manage_tea_account_inf(administerid,teacherid)values("+(Integer)user.get("id")+",1)";
		jdbcTemplate.execute(sqll);
		ModelAndView m=new ModelAndView("guanliyuanindex");
		Map<String,Object> model = m.getModel();
		model.put("curUser", user);
		return m;
	}
	//管理学生
	@RequestMapping("/guanlixuesheng")
	public ModelAndView guanlixuesheng(String xuehao,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("管理员");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		
		String sql="select * from student";
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		ModelAndView m=new ModelAndView("guanlixuesheng");
		Map<String,Object> model = m.getModel();
		model.put("curUser", user);
		model.put("courseResources", sqlList);
		return m;
	}
	@RequestMapping("/guanlixueshengyemian")
	public ModelAndView guanlixueshengyemian(String xuehao,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("管理员");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}

		int xuehao1=Integer.parseInt(xuehao.substring(0,1)+xuehao.substring(2));
		String sql="select * from student where id="+xuehao1;
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		ModelAndView m=new ModelAndView("guanlixueshengyemian");
		Map<String,Object> model = m.getModel();
		model.put("guanliyuan", user);
		model.put("user", sqlList.get(0));
		return m;
	}
	@RequestMapping(value="/guanlixueshengjieshu")
	@ResponseBody
	public ModelAndView guanlixueshengjieshu(String xuehao,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("管理员");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		xuehao=xuehao.substring(0,5);
		int xuehao1=Integer.parseInt(xuehao.substring(0,1)+xuehao.substring(2));
		String a=request.getParameter("xuehao");
		int gaihouxuehao=Integer.parseInt(a.substring(0,1)+a.substring(2));
		String sql="update student set id="+gaihouxuehao+",password='"+request.getParameter("mima")+"',phone='"+request.getParameter("lianxidianhua")
		+"',E_mail='"+request.getParameter("dianziyouxiang")+"',homeaddress='"+request.getParameter("jiatingzhuzhi")+"',qqid='"+request.getParameter("qqhao")
		+"',wechatid='"+request.getParameter("weixinhao")+"',dormitoryid='"+request.getParameter("qinshihao")+"' where id="+xuehao1;
		jdbcTemplate.execute(sql);
		String sqll="insert manage_stu_account_inf(administerid,studentid)values("+(Integer)user.get("id")+",3047)";
		jdbcTemplate.execute(sqll);
		ModelAndView m=new ModelAndView("guanliyuanindex");
		Map<String,Object> model = m.getModel();
		model.put("curUser", user);
		return m;
	}
	//管理管理员
	@RequestMapping("/guanliguanliyuan")
	public ModelAndView guanliguanliyuan(String xuehao,HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("管理员");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		ModelAndView m=new ModelAndView("guanliyuanxiugaizhanghuxinxi");
		Map<String,Object> model = m.getModel();
		model.put("user", user);
		return m;
	}
	@RequestMapping(value="/guanliyuanxiugaizhanghuxinxijieshu",method=RequestMethod.POST)
	@ResponseBody
	public ModelAndView guanliyuanxiugaizhanghuxinxijieshu(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("管理员");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		int xuehao=(Integer)user.get("id");
		String sql="update administrator set id="+Integer.parseInt(request.getParameter("id"))+",password='"+request.getParameter("mima")+"' where id="+xuehao;
		jdbcTemplate.execute(sql);
		session.removeAttribute("管理员");
		sql="select * from administrator where id="+Integer.parseInt(request.getParameter("id"));
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		session.setAttribute("管理员",sqlList.get(0));
		ModelAndView m=new ModelAndView("guanliyuanindex");
		Map<String,Object> model = m.getModel();
		model.put("curUser", sqlList.get(0));
		return m;
	}
	//创建教务处职工
	@RequestMapping("/chuangjianjiaowuchuzhigong")
	public ModelAndView chuangjianjiaowuchuzhigong(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("管理员");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		ModelAndView m=new ModelAndView("chuangjianjiaowuchuzhigong");
		Map<String,Object> model = m.getModel();
		model.put("user", user);
		return m;
	}
	@RequestMapping(value="/chuangjianjiaowuchuzhigongjieshu",method=RequestMethod.POST)
	public ModelAndView chuangjianjiaowuchuzhigongjieshu(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("管理员");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		int id=(Integer)user.get("id");
		int nid=Integer.parseInt(request.getParameter("id"));
		String npsd=request.getParameter("mima");
		String sql="insert into ac_reg_staff(id,password,admin_teacherid) values("+nid+",'"+npsd+"',"+id+")";
		jdbcTemplate.execute(sql);
		ModelAndView m=new ModelAndView("guanliyuanindex");
		Map<String,Object> model = m.getModel();
		model.put("curUser", user);
		return m;
	}
	//创建教师
	@RequestMapping("/chuangjianjiaoshi")
	public ModelAndView chuangjianjiaoshi(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("管理员");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		ModelAndView m=new ModelAndView("chuangjianjiaoshi");
		Map<String,Object> model = m.getModel();
		model.put("user", user);
		return m;
	}
	@RequestMapping(value="/chuangjianjiaoshijieshu",method=RequestMethod.POST)
	public ModelAndView chuangjianjiaoshijieshu(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("管理员");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		int id=(Integer)user.get("id");
		int nid=Integer.parseInt(request.getParameter("xuehao"));
		String sql="insert into teacher(id,password,tname,phone,e_mail,homeaddress,qqid,wechatid,admin_teacherid)"
				+ " values("+nid+",'"+request.getParameter("mima")+"','"+request.getParameter("xingming")
				+"','"+request.getParameter("lianxidianhua")+
				"','"+request.getParameter("dianziyouxiang")+"','"+
				request.getParameter("jiatingzhuzhi")+"','"+
				request.getParameter("qqhao")+"','"+
				request.getParameter("weixinhao")+"',"+
				id+")";
		jdbcTemplate.execute(sql);
		ModelAndView m=new ModelAndView("guanliyuanindex");
		Map<String,Object> model = m.getModel();
		model.put("curUser", user);
		return m;
	}
	//创建学生
	@RequestMapping("/chuangjianxuesheng")
	public ModelAndView chuangjianxuesheng(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("管理员");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		ModelAndView m=new ModelAndView("chuangjianxuesheng");
		Map<String,Object> model = m.getModel();
		model.put("user", user);
		return m;
	}
	@RequestMapping(value="/chuangjianxueshengjieshu",method=RequestMethod.POST)
	public ModelAndView chuangjianxueshengjieshu(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("管理员");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		String a=request.getParameter("xuehao");
		System.out.println(a);
		int id=(Integer)user.get("id");
		int nid=Integer.parseInt(a);
		String sql="insert into student(id,password,sname,phone,e_mail,homeaddress,qqid,wechatid,dormitoryid,admin_teacherid)"
				+ " values("+nid+",'"+request.getParameter("mima")+"','"+request.getParameter("xingming")
				+"','"+request.getParameter("lianxidianhua")+
				"','"+request.getParameter("dianziyouxiang")+"','"+
				request.getParameter("jiatingzhuzhi")+"','"+
				request.getParameter("qqhao")+"','"+
				request.getParameter("weixinhao")+"','"+
				request.getParameter("qinshihao")+"',"+id+")";
		jdbcTemplate.execute(sql);
		ModelAndView m=new ModelAndView("guanliyuanindex");
		Map<String,Object> model = m.getModel();
		model.put("curUser", user);
		return m;
	}
	//创建管理员
	@RequestMapping("/chuangjianguanliyuan")
	public ModelAndView chuangjianguanliyuan(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("管理员");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		ModelAndView m=new ModelAndView("chuangjianguanliyuan");
		Map<String,Object> model = m.getModel();
		model.put("user", user);
		return m;
	}
	@RequestMapping(value="/chuangjianguanliyuanjieshu",method=RequestMethod.POST)
	public ModelAndView chuangjianguanliyuanjieshu(HttpServletRequest request,HttpSession session) {
		Map<String,Object> user=(Map<String,Object>)session.getAttribute("管理员");
		if(user==null) {
			ModelAndView m=new ModelAndView("ceshi2");
			return m;
		}
		int id=(Integer)user.get("id");
		int nid=Integer.parseInt(request.getParameter("id"));
		String npsd=request.getParameter("mima");
		String sql="insert into administrator(id,password,admin_teacherid) values("+nid+",'"+npsd+"',"+id+")";
		jdbcTemplate.execute(sql);
		ModelAndView m=new ModelAndView("guanliyuanindex");
		Map<String,Object> model = m.getModel();
		model.put("curUser", user);
		return m;
	}
}
