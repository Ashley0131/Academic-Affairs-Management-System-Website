package bao1.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import bao1.dao.IUserRepository;
import bao1.entity.User;

@Controller
public class LoginController {
	@Autowired
	private IUserRepository userRepository;
	
	//private boolean logined=false;
	@RequestMapping("/loginverify1")
	@ResponseBody
	public String verify(HttpServletRequest request) {
		String account =request.getParameter("account1");
		String password=request.getParameter("password1");
		System.out.println("接收到的账户密码是"+account+","+password);
		//return account+","+password;
		List<User> users=userRepository.findAll();
		for(int i=0;i<users.size();i++) {
			if(users.get(i).getAccount().equals(account)) {
				if(users.get(i).getPassword().equals(password)) {
					//logined=true;
					return "登陆成功";
				}
				return "密码错误";
			}
		}
		return "没有此用户";
	}
}
