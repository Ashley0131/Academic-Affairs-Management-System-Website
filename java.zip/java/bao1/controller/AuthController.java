package bao1.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
//@RestController
public class AuthController {
	
	private Logger logger=LoggerFactory.getLogger(AuthController.class);

	@Autowired
	private JdbcTemplate jdbcTemplate;
	@RequestMapping("/login")
	public ModelAndView login() {
		ModelAndView mv=new ModelAndView("ceshi2");
		return mv;
	}
	@RequestMapping("/studentlogin")
	public ModelAndView xueshenglogin() {
		ModelAndView mv=new ModelAndView("ceshi");
		Map<String,Object> model = mv.getModel();
		model.put("leibie", "学生");
		return mv;
	}
	@RequestMapping("/guanliyuanlogin")
	public ModelAndView guanliyuanlogin() {
		ModelAndView mv=new ModelAndView("ceshi");
		Map<String,Object> model = mv.getModel();
		model.put("leibie", "管理员");
		return mv;
	}
	@RequestMapping("/jiaowuchuzhigonglogin")
	public ModelAndView jiaowuchuzhigonglogin() {
		ModelAndView mv=new ModelAndView("ceshi");
		Map<String,Object> model = mv.getModel();
		model.put("leibie", "教务处职工");
		return mv;
	}
	@RequestMapping("/jiaoshilogin")
	public ModelAndView jiaoshilogin() {
		ModelAndView mv=new ModelAndView("ceshi");
		Map<String,Object> model = mv.getModel();
		model.put("leibie", "教师");
		return mv;
	}

	@RequestMapping(value="/loginverify",method=RequestMethod.POST)
	@ResponseBody
	public ModelAndView loginVerify(String leibie,HttpServletRequest request,HttpSession session) {
		String account =request.getParameter("yonghuming");
		String password=request.getParameter("mima");
		logger.info("接收到的账户密码是"+account+","+password);
		//在数据库中查找
		String weizhi=null;
		if(leibie.equals("学生"))weizhi="student";
		else if(leibie.equals("管理员"))weizhi="administrator";
		else if (leibie.equals("教师"))weizhi="teacher";
		else weizhi="ac_reg_staff";
		String sql="select * from "+weizhi+" where id='"+account+"'";
		List<Map<String,Object>> sqlList=jdbcTemplate.queryForList(sql);
		
		if(sqlList.size()==0||!sqlList.get(0).get("password").equals(password)) {
			ModelAndView mv=new ModelAndView("ceshi2");
			return mv;
		}
		else {
			session.setAttribute(leibie,sqlList.get(0));
			//根据类别打开页面
			//ModelAndView mv=new ModelAndView(weizhi+"index");
			ModelAndView mv;
			if(leibie.equals("学生"))mv=new ModelAndView("xuesheng"+"index");
			else if(leibie.equals("管理员"))mv=new ModelAndView("guanliyuan"+"index");
			else if (leibie.equals("教师"))mv=new ModelAndView("jiaoshi"+"index");
			else mv=new ModelAndView("jiaowuchuzhigong"+"index");
			Map<String,Object> model = mv.getModel();
			model.put("curUser", sqlList.get(0));
			return mv;
		}
	}
	@RequestMapping("/xueshengzhuxiao")
	public ModelAndView xueshengzhuxiao(HttpServletRequest request,HttpSession session) {
		session.removeAttribute("学生");
		ModelAndView mv=new ModelAndView("ceshi2");
		return mv;
	}
	@RequestMapping("/jiaoshizhuxiao")
	public ModelAndView jiaoshizhuxiao(HttpServletRequest request,HttpSession session) {
		session.removeAttribute("教师");
		ModelAndView mv=new ModelAndView("ceshi2");
		return mv;
	}
	@RequestMapping("/guanliyuanzhuxiao")
	public ModelAndView guanliyuanzhuxiao(HttpServletRequest request,HttpSession session) {
		session.removeAttribute("管理员");
		ModelAndView mv=new ModelAndView("ceshi2");
		return mv;
	}
	@RequestMapping("/jiaowuchuzhigongzhuxiao")
	public ModelAndView jiaowuchuzhigongzhuxiao(HttpServletRequest request,HttpSession session) {
		session.removeAttribute("教务处职工");
		ModelAndView mv=new ModelAndView("ceshi2");
		return mv;
	}
}
